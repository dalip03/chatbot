export const chatData = [
    {
     question:'How old are u?',
     option:[
       {item:'less than 18'},
       {item:'less than 20'},
       {item:'less than 25'},
       { item: 'less than 30' },
     ]
    },
     {
       question: 'Are u male or female?',
       option: [
         { item: 'Male' },
         { item: 'Female' },
       ]
     },

     {
        question:'How old are u?',
        option:[
          {item:'less than 18'},
          {item:'less than 20'},
          {item:'less than 25'},
          { item: 'less than 30' },
        ]
       },
        {
          question: 'Are u male or female?',
          option: [
            { item: 'Male' },
            { item: 'Female' },
          ]
        },

        {
            question:'How old are u?',
            option:[
              {item:'less than 18'},
              {item:'less than 20'},
              {item:'less than 25'},
              { item: 'less than 30' },
            ]
           },
            {
              question: 'Are u male or female?',
              option: [
                { item: 'Male' },
                { item: 'Female' },
              ]
            },

            {
                question:'How old are u?',
                option:[
                  {item:'less than 18'},
                  {item:'less than 20'},
                  {item:'less than 25'},
                  { item: 'less than 30' },
                ]
               },
                {
                  question: 'Are u male or female?',
                  option: [
                    { item: 'Male' },
                    { item: 'Female' },
                  ]
                },

                {
                    question:'How old are u?',
                    option:[
                      {item:'less than 18'},
                      {item:'less than 20'},
                      {item:'less than 25'},
                      { item: 'less than 30' },
                    ]
                   },
                    {
                      question: 'Are u male or female?',
                      option: [
                        { item: 'Male' },
                        { item: 'Female' },
                      ]
                    },
                ]
