import {combineReducers} from 'redux'
import chatReducer from '../Reducer/chatReducer'
let reducers = combineReducers({chatReducer})


export default reducers